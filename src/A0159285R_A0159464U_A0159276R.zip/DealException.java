/**
 * Created by huanyuhello on 5/9/2016.
 */
public class DealException extends Exception {
}
