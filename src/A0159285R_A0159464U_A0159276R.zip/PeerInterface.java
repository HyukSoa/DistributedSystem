import java.rmi.Remote;

/**
 * Created by huanyuhello on 5/9/2016.
 */
public interface PeerInterface extends Remote {
}
