/**
 * Created by huanyuhello on 5/9/2016.
 */
public enum MoveAction {
    goUp, goDown, goRight, goLeft;
}
